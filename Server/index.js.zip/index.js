const express = require('express');
const http = require('http');
const socketIO = require('socket.io');
const app = express();
const server = http.createServer(app);
const io = socketIO(server);
const PORT = 3000;
const MAX_USERS_PER_NAMESPACE = 2;
const namespaces = [];

server.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});

io.on('connection', (socket) => {

  console.log(`=> A User connected with id: ${socket.id}`);

  for (const ns of namespaces) {
    console.log(`=> Current namespace ${ns.name}: , count: ${ns.users.length}`);
  }

  let namespace;
  for (const ns of namespaces) {
    if (ns.users.length < MAX_USERS_PER_NAMESPACE) {
      namespace = ns;
      console.log(`=> Available namespace found: ${namespace.name}`);
      break;
    }
  }

  if (!namespace) {
    console.log(`=> No available namespace found !`);
    namespace = createNamespace();
    console.log(`=> New namespace created: ${namespace.name}`);
  }

  console.log(`=> Proceeding with namespace: ${namespace.name}, count: ${namespace.users.length}`);

  console.log(`=> Joining user to namespace: ${namespace.name}, count: ${namespace.users.length}`);
  socket.join(namespace.name);

  namespace.users.push(socket.id);
  console.log(`=> Pushed user ${socket.id} onto namespace: ${namespace.name}, count: ${namespace.users.length}`);

  socket.emit('userConnected', namespace.name);
  console.log(`=> Emitting ${socket.id} 'userConnected' to namespace: ${namespace.name}, count: ${namespace.users.length}`);

  socket.emit('namespaceAssigned', namespace.name);
  console.log(`=> Emitting ${socket.id} 'namespaceAssigned' to namespace: ${namespace.name}, count: ${namespace.users.length}`);

  socket.on('disconnectNamespace', (namespaceName) => {

    console.log(`=> Disconnecting ${socket.id} from namespace ${namespaceName}`);

    const targetNamespace = namespaces.find((namespace) => namespace.name === namespaceName);

    if (targetNamespace) {

      console.log(`=> Found namespace to disconnect ${socket.id} from: ${targetNamespace.name}, count: ${targetNamespace.users.length}`);

      const index = targetNamespace.users.indexOf(socket.id);
      console.log(`=> Searching disconnecting user ${socket.id} to disconnect from namespace: ${targetNamespace.name}`);

      if (index !== -1) {

        // notify other users on namespace of user disconnection
        const message = `${socket.id} has disconnected.`;
        socket.to(targetNamespace.name).emit('userDisconnected', message);
        console.log(`=> Emitting ${socket.id} 'userDisconnected' to namespace: ${namespaceName}, count: ${targetNamespace.users.length}`);

        console.log(`=> Found ${socket.id} disconnecting user in namespace: ${targetNamespace.name}, count: ${targetNamespace.users.length}`);

        targetNamespace.users.splice(index, 1);
        console.log(`=> Disconnected ${socket.id} user from namespace: ${targetNamespace.name}, count: ${targetNamespace.users.length}`);

        if (targetNamespace.users.length === 0) {
          console.log(`=> No more users connected to namespace: ${targetNamespace.name}, count: ${targetNamespace.users.length}`);
          const indexToRemove = namespaces.indexOf(targetNamespace);
          console.log(`=> Searching namespace to clear from namespaces: ${targetNamespace.name}, namespaces count: ${namespaces.length}`);

          if (indexToRemove !== -1) {
            namespaces.splice(indexToRemove, 1);
            console.log(`=> Namespace ${targetNamespace.name} removed due to no users.`);
            console.log(`=> Updated name space count count: ${namespaces.length}`);
          }
        } else {
          console.log(`=> Namespace ${targetNamespace.name} having ${targetNamespace.users.length} users.`);
          console.log(`=> Updated name space count count: ${namespaces.length}`);
          io.to(targetNamespace.name).emit('userDisconnected', message);
        }
      }
    }

    if (namespaces.length >= 2) {
      
      const namespacesWithOneUser = namespaces.filter((ns) => ns.users.length === 1);
      
      if (namespacesWithOneUser.length >= 2) {

        console.log(`=> Found namespaces with 1 user viz. ${namespacesWithOneUser[0].name} and ${namespacesWithOneUser[1].name}`);
        console.log(`=> User on namespace ${namespacesWithOneUser[0].name} is ${namespacesWithOneUser[0].users[0]}`);
        console.log(`=> User on namespace ${namespacesWithOneUser[1].name} is ${namespacesWithOneUser[1].users[0]}`);

        const userFromNamespace1 = namespacesWithOneUser[0].users[0];
        const userFromNamespace2 = namespacesWithOneUser[1].users[0];

        // Emit a 'rematch' event to one of the namespaces
        io.to(namespacesWithOneUser[1].name).emit('rematch', {
          namespace: namespacesWithOneUser[0].name,
          user: userFromNamespace2,
        });

        console.log(`=> Matched users from ${namespacesWithOneUser[0].name} and ${namespacesWithOneUser[1].name}`);

        // Remove only the second namespace
        const indexToRemove = namespaces.indexOf(namespacesWithOneUser[1]);
        if (indexToRemove !== -1) {
          namespaces.splice(indexToRemove, 1);
          console.log(`=> Removing ${userFromNamespace2} namespace for rematch, ${namespacesWithOneUser[1].name}.`);
          console.log(`=> Updated namespace count: ${namespaces.length}`);
        }
      }
    }

  });

  //TODO: Debug issue on first run where for 3 users, if user 1 & 2 disconnect one by one, the third user still stays connected
  // This causes the player to stay in the in game state
  socket.on('rejoinNamespace', (namespaceName) => {

    console.log(`=> Rejoining ${socket.id} on namespace: ${namespaceName}`);
    
    const targetNamespace = namespaces.find((namespace) => namespace.name === namespaceName);

    if (targetNamespace) {
      console.log(`=> Found namespace to rejoin ${socket.id} to: ${targetNamespace.name}, count: ${targetNamespace.users.length}`);
      socket.join(targetNamespace);

      console.log(`=> Pushing ${socket.id} user on rejoining namespace: ${targetNamespace.name}, count: ${targetNamespace.users.length}`);

      const index = targetNamespace.users.indexOf(socket.id);
      if (index === -1) {

        targetNamespace.users.push(socket.id);
        console.log(`=> Pushed ${socket.id} user on rejoining namespace: ${targetNamespace.name}, count: ${targetNamespace.users.length}`);

        socket.emit('userConnected', targetNamespace.name);
        console.log(`=> Emitting ${socket.id} 'userConnected' on rejoining namespace: ${targetNamespace.name}, count: ${targetNamespace.users.length}`);

        socket.emit('namespaceAssigned', targetNamespace.name);
        console.log(`=> Emitting ${socket.id} 'namespaceAssigned' to rejoin namespace: ${targetNamespace.name}, count: ${targetNamespace.users.length}`);
      }

      if (targetNamespace.users.length === MAX_USERS_PER_NAMESPACE) {
        console.log(`=> Enough members for game in namespace: ${targetNamespace.name}, count: ${targetNamespace.users.length}`);
        // notify current socket
        socket.emit('foundOpponent')
        // notify other sockets on the same namespace
        socket.to(targetNamespace.name).emit('foundOpponent');
        console.log(`=> Emitting ${socket.id} 'foundOpponent' to namespace: ${targetNamespace.name}, count: ${targetNamespace.users.length}`);
      }
    }

  });

  if (namespace.users.length === MAX_USERS_PER_NAMESPACE) {
    console.log(`=> Enough members for game in namespace: ${namespace.name}, count: ${namespace.users.length}`);
    // notify current socket
    socket.emit('foundOpponent')
    // notify other sockets on the same namespace
    socket.to(namespace.name).emit('foundOpponent');
    console.log(`=> Emitting ${socket.id} 'foundOpponent' to namespace: ${namespace.name}, count: ${namespace.users.length}`);
  }

});

function createNamespace() {
  const name = `namespace_${namespaces.length + 1}`;
  const users = [];
  namespaces.push({ name, users });

  return { name, users };
}
